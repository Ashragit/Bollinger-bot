import pandas as pd
import ta

def compute_bollinger(df, length=20, mult=2.0):
    indicator = ta.volatility.BollingerBands(close=df["close"], window=length, window_dev=mult)
    df["bb_upper"] = indicator.bollinger_hband()
    df["bb_lower"] = indicator.bollinger_lband()
    df["bb_basis"] = indicator.bollinger_mavg()
    return df

def check_signal(df):
    last = df.iloc[-1]
    prev = df.iloc[-2]

    signal = None
    if prev["close"] < prev["bb_lower"] and last["close"] > last["bb_lower"]:
        signal = "buy"
    elif prev["close"] > prev["bb_upper"] and last["close"] < last["bb_upper"]:
        signal = "sell"
    return signal
