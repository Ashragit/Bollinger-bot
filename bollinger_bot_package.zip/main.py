from binance.client import Client
from config import *
import pandas as pd
from strategy_logic import compute_bollinger, check_signal
import time

client = Client(BINANCE_API_KEY, BINANCE_API_SECRET)

def fetch_ohlcv(symbol, interval="1m", limit=100):
    klines = client.get_klines(symbol=symbol, interval=interval, limit=limit)
    df = pd.DataFrame(klines, columns=[
        "timestamp", "open", "high", "low", "close", "volume",
        "close_time", "quote_asset_volume", "num_trades", 
        "taker_buy_base", "taker_buy_quote", "ignore"])
    df["close"] = df["close"].astype(float)
    return df[["timestamp", "close"]]

def place_order(side):
    print(f"{side.upper()} order பண்ண போறோம்...")
    try:
        if side == "buy":
            client.order_market_buy(symbol=SYMBOL, quantity=TRADE_QUANTITY)
        elif side == "sell":
            client.order_market_sell(symbol=SYMBOL, quantity=TRADE_QUANTITY)
    except Exception as e:
        print("Order Failed:", e)

def run_bot():
    while True:
        df = fetch_ohlcv(SYMBOL)
        df = compute_bollinger(df)
        signal = check_signal(df)
        if signal:
            place_order(signal)
        time.sleep(60)

if __name__ == "__main__":
    run_bot()
